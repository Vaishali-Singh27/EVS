package com.wipro.evs.controller;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.evs.bean.*;
import com.wipro.evs.dao.DAO;
import com.wipro.evs.service.*;


public class Controller extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String trigerFrom = request.getParameter("evsButton");
		
		 HttpSession session = request.getSession();
		 
		//change password
	        
         if(trigerFrom.equalsIgnoreCase("ChangePassword")) {
                System.out.println("in controller...Change password");
                String userName1 = request.getParameter("username");
                int reqId1 = Integer.parseInt(request.getParameter("reqid"));
                String pass1 = request.getParameter("password");
                Service q = new Service();
                int c=q.setPassWordVoter(userName1, reqId1, pass1);
               
                System.out.println("in controller...after Changed password");
                if(c> 0) {
    				response.sendRedirect("index1.jsp");
    			}
    			else {
    				response.sendRedirect("ForgetPassword.jsp");
    			}
               
                //response.sendRedirect("LandingPage.jsp");
            }
		
		//login
		if(trigerFrom.equalsIgnoreCase("login"))
		{
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String role = "";
			
			//session
			session.setAttribute("uName", username);
			session.setAttribute("pass", password);
			session.setAttribute("role", role);
			
			LoginBean bn = new LoginBean();
			bn.setUserName(username);
			bn.setPassword(password);
			bn.setRole(role);
			
			Service svc = new Service();
			LoginBean loginStatusBean = svc.doLogin(bn);
			
			if(loginStatusBean != null){
				role = loginStatusBean.getRole();
				//System.out.println(role+" "+loginStatusBean.getPassword());
				if(role.equalsIgnoreCase("Admin"))
					response.sendRedirect("LandingAdminsPageSuccess.jsp");
				if(role.equalsIgnoreCase("Voter"))
					response.sendRedirect("LandingVotersPageSuccess.jsp");
				if(role.equalsIgnoreCase("officer"))
					response.sendRedirect("LandingOfficersPageSuccess.jsp");
			}
			else
				response.sendRedirect("LandingLoginFail.jsp");
		}
		
		
		//tested
		// AD001: Adding election details
		if(trigerFrom.equalsIgnoreCase("add election details")){			
			int id = 0;
			String name = request.getParameter("electionname");
			String date=request.getParameter("electiondate");
			String status ="Pending";
			String result = "Not declared";
					
			ElectionDetails detailsBean = new ElectionDetails();
			detailsBean.setElectionId(id);
			detailsBean.setElectionName(name);
			detailsBean.setElectionDate(date);
			detailsBean.setElectionStatus(status);
			detailsBean.setResult(result);
					
			Service svc = new Service();
			int detailsAdded = svc.addElectionDetails(detailsBean);
			if(detailsAdded > 0)
				response.sendRedirect("ElectionDetailsAddedSuccess.jsp");
			else
				response.sendRedirect("ElectionDetailsAddedFail.jsp");
		}
						
		//tested	
		// AD002: View upcoming elections.
		if(trigerFrom.equalsIgnoreCase("view upcoming election")){
			String d=java.time.LocalDate.now().toString();
			//System.out.println(d);
		    String da[]=d.split("-");
		    String date=da[2]+"-"+da[1]+"-"+da[0];
		    System.out.println(date);//for testing
			Service svc = new Service();
			ArrayList<ElectionDetails> upcomingBeanList = svc.viewUpcomingElections(date);
			System.out.println(date);//for testing
			
			if(upcomingBeanList.size()>0){
				request.setAttribute("data", upcomingBeanList);
				RequestDispatcher rd = request.getRequestDispatcher("ViewUpcomingElectionSuccess.jsp");
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("ViewUpcomingElectionFail.jsp");
			}
		}

		
		//tested
		// AD003: View election details.
		if(trigerFrom.equalsIgnoreCase("view election details")){
			Service svc = new Service();
			ArrayList<ElectionDetails> electionDetailsList = svc.viewElectionDetails();
			
			if(electionDetailsList.size()>0){
				//System.out.println(electionDetailsList.size());
				request.setAttribute("data", electionDetailsList);
      			RequestDispatcher rd = request.getRequestDispatcher("ViewElectionDetailsSuccess.jsp");
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("ViewElectionDetailsFail.jsp");
			}
		}

		
		//tested
		//AD004: Add Party Details
		if(trigerFrom.equalsIgnoreCase("add Party details")){			
			String name = request.getParameter("party_name");
			String date = request.getParameter("established_date");
			String result = request.getParameter("president");
			
			PartyDetails detailsBean = new PartyDetails();
			detailsBean.setPartyName(name);
			detailsBean.setPartyDate(date);
			detailsBean.setPartyPresident(result);
			//System.out.println("Controller");
			Service svc = new Service();
			int detailsAdded = svc.addPartyDetails(detailsBean);
			if(detailsAdded > 0)
				response.sendRedirect("PartyDetailsAddedSuccess.jsp");
			else
				response.sendRedirect("PartyDetailsAddedFail.jsp");
		}

		
		//tested
		// AD005: View Party Details.
		if(trigerFrom.equalsIgnoreCase("view Party details")){			
			
			Service svc = new Service();
			ArrayList<PartyDetails> beans = svc.viewAllPartyDetails();
			
			if(beans.size()>0){
				request.setAttribute("data", beans);
				RequestDispatcher rd = request.getRequestDispatcher("ViewPartyDetailsSuccess.jsp");
				rd.forward(request, response);
			}
				else
				response.sendRedirect("ViewPartyDetailsFail.jsp");
		}
	
	
		//AD006: Assign candidate to election.
		if(trigerFrom.equalsIgnoreCase("Assign Candidate Against Particular Election")){
			Service svc = new Service();
			String d=java.time.LocalDate.now().toString();
		    String da[]=d.split("-");
		    String date=da[2]+"-"+da[1]+"-"+da[0];
		    
		    ArrayList<PartyDetails> partyName = svc.viewAllPartyDetails();
			ArrayList<String> s=svc.viewUpcomingElectionNames(date);
			
			if(partyName.size()>0 && s.size()>0)
			{
				request.setAttribute("partyName", partyName);
				request.setAttribute("electionNames", s);
				RequestDispatcher rd=request.getRequestDispatcher("AssignCandidateAgainstElection.jsp");
				rd.forward(request, response);
			}
			else
			{
				response.sendRedirect("ViewPartyDetailsFail.jsp");
			}
			// Get details from user:
			
		}
		if(trigerFrom.equalsIgnoreCase("Add Candidate"))
		{
			//int candidateID = Integer.parseInt(request.getParameter("Candidate ID"));
			String name = request.getParameter("Candidate name");
			String party = request.getParameter("Candidate party");
			String elName = request.getParameter("Election name");
			//System.out.println(name+" "+party+ " "+elName);
			// Package data entered by user into a bean object:
			CandidateDetails candidateBean = new CandidateDetails();
			//candidateBean.setId(candidateID);
			candidateBean.setCandidateName(name);
			candidateBean.setCandidateParty(party);
			candidateBean.setElectionID(-1);
			candidateBean.setElectionName(elName);
			
			// Call the Service class:
			Service svc=new Service();
			int candidateAssigned = svc.assignCandidateToElection(candidateBean);
			
			// Redirect as applicable:
			if(candidateAssigned > 0)
			{
				System.out.println("asdfasfas 1::"+candidateAssigned);
				//RequestDispatcher dd = request.getRequestDispatcher("CandidateAssignSuccess.jsp");

				//dd.forward(request, response);

				response.sendRedirect("CandidateAssignSuccess.jsp");
			}
			if(candidateAssigned==-1) {
				System.out.println("2");
				String message = new String("Candidate already exist.");
				response.sendRedirect("CandidateAssignFail.jsp?message="+message);
			}
			if(candidateAssigned==0)
			{
				System.out.println("3");
				String message = new String("Candidate Assign Fail");
				response.sendRedirect("CandidateAssignFail.jsp?message="+message);
			}
		}
	
		
		// AD007: View candidate against particular election.
		if(trigerFrom.equalsIgnoreCase("View Candidate")){
			
			String elName = request.getParameter("Election name");
			
			//Task incomplete fetch name from jsp
			
			//String elName="LOKSABHA"; 
			// Package data entered by user into a bean object:
			ElectionDetails electionBean = new ElectionDetails();
			electionBean.setElectionName("");
			electionBean.setElectionDate(null);
			electionBean.setElectionId(-1);
			electionBean.setElectionStatus("");
			electionBean.setElectionName(elName);
			
			// Call the Service class:
			Service svc = new Service();
			ArrayList<CandidateDetails> detailsFound = svc.viewCandidatesAgainstElection(electionBean);
			
			// Redirect as applicable:
			if(detailsFound.size() > 0) {
				request.setAttribute("data",detailsFound);
				RequestDispatcher rd = request.getRequestDispatcher("ViewAllCandidatesAgainstElectionSuccess.jsp");
				rd.forward(request, response);
			}
			else
				response.sendRedirect("ViewAllCandidateAgainstElectionFail.jsp");
		}
	

		//tested
		//AD008: Admin wants to view pending voter's request
		if (trigerFrom.equalsIgnoreCase("View Pending Voter's Request")) {
			Service svc = new Service();
			ArrayList<VoterRegistration> voters = svc.getPendingVoters();
			//System.out.println("Controller "+voters.size());
			if(voters.size() > 0) {
				request.setAttribute("data", voters);
				RequestDispatcher rd = request.getRequestDispatcher("ViewPendingVoterListSuccess.jsp");
				rd.forward(request, response);		
			}
			else {
				response.sendRedirect("ViewPendingVoterListFail.jsp");	
			}
		}
		
		
		//tested
		// AD009: View all candidates.
		if(trigerFrom.equalsIgnoreCase("view all candidates")){
			Service svc = new Service();
			ArrayList<CandidateDetails> candidatesList = svc.viewAllCandidates();
			
			if(candidatesList.size()>0){
				request.setAttribute("data", candidatesList);
				RequestDispatcher rd = request.getRequestDispatcher("ViewAllCandidatesSuccess.jsp");
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("ViewAllCandidatesFail.jsp");
			}
		}		
		
		

		//AD-010
				if(trigerFrom.equalsIgnoreCase("Approve Results")) {			
					Service service = new Service();
					ArrayList<String> electionNameList = service.getAdminElectionName();
					
					if(electionNameList.size()>0) {
						
						request.setAttribute("data", electionNameList);
						RequestDispatcher rd = request.getRequestDispatcher("ViewElectionResult.jsp");
						
						rd.forward(request, response);	
					}else {	
						response.sendRedirect("viewElectionResultFail.jsp");		
					}	
				}
				if(trigerFrom.equalsIgnoreCase("View Results")) {
					Service service = new Service();
					String name = request.getParameter("electionName");
					ArrayList<String> viewBeforeApprove = service.viewResults_approve(name);
					if(viewBeforeApprove.size()>0) {
									
									request.setAttribute("data", viewBeforeApprove);
									request.setAttribute("electionName",name);
									System.out.println("Before Result 1");
									RequestDispatcher rd = request.getRequestDispatcher("ViewElectionResultBeforeApprove.jsp");
									System.out.println("Before Result 2");
									rd.forward(request, response);	
									System.out.println("Before Result 3");
								}else {	
									response.sendRedirect("ViewElectionResultBeforeApproveFail.jsp");		
								}	
					
				}
				if(trigerFrom.equalsIgnoreCase("Approve-Result")) {
					Service service = new Service();
					String name = request.getParameter("electionName");
					System.out.println("Inside Click to view results"+name);
					ArrayList<String[]> resultList = service.receiveResults(name);
					
					if(resultList.size()>0) {		
					request.setAttribute("result", resultList);
		      			RequestDispatcher rd = request.getRequestDispatcher("DisplayElectionResults.jsp");
						rd.forward(request, response);
					}
					else {
						response.sendRedirect("DisplayElectionResultsFail.jsp");
					}
				}

		//tested
		//EO-001
		if(trigerFrom.equalsIgnoreCase("View Voter Request")){
			
			Service svc = new Service();
			ArrayList<VoterRegistration> RegistrationList = svc.viewAllRegistraions();
				
			//System.out.println("size "+RegistrationList.size());//for testing
			if(RegistrationList.size()>0){
			
				request.setAttribute("data", RegistrationList);
	      		RequestDispatcher rd = request.getRequestDispatcher("ViewVoterRequestSuccess.jsp");
	      		
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("ViewVoterRequestFail.jsp");
			}
		}
		
		
		//tested	
		//EO-002
		if(trigerFrom.equalsIgnoreCase("Generate VoterId")){
			Service svc = new Service();
			ArrayList<String> regId=svc.getRegIdList();
			
			//System.out.println("Controller "+regId.size());//for testing
			if(regId.size()>0)
			{
				request.setAttribute("data", regId);
				request.getRequestDispatcher("OfficerGenerateVoterId.jsp").forward(request, response);
			}
			else
				response.sendRedirect("OfficerGenerateVoterIdFail.jsp");
		}
		if(trigerFrom.equalsIgnoreCase("Approve Voter")) {			
			String id = request.getParameter("optionid");
			//System.out.println(id);
			Service service = new Service();				
			int check = service.approveVoter(id);

			
			Service svc = new Service();
			ArrayList<String> regId=svc.getRegIdList();
			
			//System.out.println("Controller "+regId.size());//for testing
			if(regId.size()>0)
			{
				String message = new String("Voter Id Assigned");
				request.setAttribute("data", regId);
				request.getRequestDispatcher("OfficerGenerateVoterId.jsp").forward(request, response);
				
			}
			else
				response.sendRedirect("OfficerGenerateVoterIdFail.jsp");
		}
		if(trigerFrom.equalsIgnoreCase("Reject Voter")) {				
			String id = request.getParameter("optionid");					
			Service service = new Service();					
			int check = service.rejectVoter(id);

			Service svc = new Service();
			ArrayList<String> regId=svc.getRegIdList();
			
			//System.out.println("Controller "+regId.size());//for testing
			if(regId.size()>0)
			{
				request.setAttribute("data", regId);
				request.getRequestDispatcher("OfficerGenerateVoterId.jsp").forward(request, response);
			}
			else
				response.sendRedirect("OfficerGenerateVoterIdFail.jsp");
			
		}
			

		//US-001: Voter wants to register to voting system
		if(trigerFrom.equalsIgnoreCase("Voter Registration")) {
			String name = request.getParameter("name");
			String dob = request.getParameter("dob");
			String address = request.getParameter("address");
			String userName = request.getParameter("username");
			String passWord = request.getParameter("password");
			
			LoginBean lb = new LoginBean();
			lb.setUserName(userName);
			lb.setPassword(passWord);
			lb.setRole("Voter");
			Service ser = new Service();
			String status = ser.addVoterLoginDetails(lb);
			if(status.equals("success")) {
				VoterRegistration vr = new VoterRegistration();
				vr.setVoterName(name);
				vr.setVoterDOB(dob);
				vr.setVoterAddress(address);
				vr.setUserName(userName);
				int requestID = ser.registerVoter(vr);
				if(requestID>0) {
					response.sendRedirect("VoterRegisterSuccess.jsp?req_id="+requestID);
				}
				else {
					String message = new String("");
					response.sendRedirect("VoterRegisterFail.jsp?message="+message);
				}
				
				
			}
			if(status.equals("Exist")) {
				
				String message = new String("User name already exist");
				response.sendRedirect("VoterRegisterFail.jsp?message="+message);
				
			}
			else if(status==null){
				String message = new String();
				response.sendRedirect("VoterRegisterFail.jsp?message="+message);
			}	
		}

		
		//US-002: Voter want to request for VOTER-ID
		if(trigerFrom.equals("Get Voter-id")) {
			int reqID = Integer.parseInt(request.getParameter("req_id"));
			//System.out.println("Controller");//for testing
			//VoterDetails vd = new VoterDetails();
			Service serv = new Service();
			int voterID = serv.getVoterID(reqID);
			//System.out.println("Controller "+voterID);//for testing
			if (voterID > 0) {
				response.sendRedirect("RequestVoterIDSuccess.jsp?vtr_id="+voterID);
			} else {
				response.sendRedirect("RequestVoterIDFail.jsp");
			}
		}
		
		
		//US-003 : Voter wants to view my VOTER-ID
		if(trigerFrom.equalsIgnoreCase("View Voter-ID")) {
			Service service = new Service();
			String name = (String) session.getAttribute("uName");
			int voterId = service.getVoterIdService(name);
			VoterDetails vd = new VoterDetails();
			vd.setVoterId(voterId); 
			VoterDetails vdt = service.voterIdDetails(vd);
			if(vdt.getVoterId() > 0) {
				request.setAttribute("voterDetails", vdt);
	      		request.getRequestDispatcher("ViewVoterIdSuccess.jsp").forward(request, response);;
			}
			else {
				response.sendRedirect("ViewVoterIdFail.jsp");
			}
		}
		
		
		//tested
		//US-004 same as AD-002
		if(trigerFrom.equalsIgnoreCase("view upcoming election voter")){
			String d=java.time.LocalDate.now().toString();
		    String da[]=d.split("-");
		    String date=da[2]+"-"+da[1]+"-"+da[0];
			Service svc = new Service();
			ArrayList<ElectionDetails> upcomingBeanList = svc.viewUpcomingElections(date);
			//System.out.println(date);//for testing
			
			if(upcomingBeanList.size()>0){
				request.setAttribute("data", upcomingBeanList);
				RequestDispatcher rd = request.getRequestDispatcher("ViewUpcomingElectionSuccessVoter.jsp");
				rd.forward(request, response);
			}
			else{
				response.sendRedirect("ViewUpcomingElectionFailVoter.jsp");
			}
		}
		
		
		//tested
		//US-005
		if(trigerFrom.equals("See Candidates Based on Election")) {
			Service serv = new Service();
			ArrayList<String> electionName=serv.getElectionName();
			//System.out.println("Controller "+electionName.size());
			if(electionName.size()>0)
			{
				request.setAttribute("data", electionName);
				RequestDispatcher rdtr = request.getRequestDispatcher("ViewCandDetailsBasedOnElecSuccess.jsp");
				rdtr.forward(request, response);
			}
			else
				response.sendRedirect("ViewCandDetailsBasedOnElecFail.jsp");
		}
		if(trigerFrom.equals("View Election")) {
			String electionName=request.getParameter("electionname");
			Service svc=new Service();
			ArrayList<CandidateDetails> list=svc.getCandidateDetailsByElection(electionName);
			
			if(list.size()>0) {
				request.setAttribute("data", list);
				RequestDispatcher rdtr = request.getRequestDispatcher("ViewAllCandidatesAgainstElectionSuccessVoter.jsp");
				rdtr.forward(request, response);
			}else
				response.sendRedirect("ViewAllCandidatesAgainstElectionFailVoter.jsp");
			}
			

		// US006: Casting my vote.
		if(request.getParameter("evsButton").equalsIgnoreCase("cast my vote")){
			
			//Check if Voter is Authenticated
			String uName1 = (String) session.getAttribute("uName");
			Service ser = new Service();
			int voterID = ser.getVoterIdService(uName1);
			if(voterID > 0) {
				ArrayList<String> c=new ArrayList<String>();
			Service svc = new Service();
			String d=java.time.LocalDate.now().toString();
			//System.out.println("Date"+d);
		    String da[]=d.split("-");
		    String date=da[2]+"-"+da[1]+"-"+da[0];
			//String date="12-12-2020";
		    ElectionDetails s=svc.getTodaysElection(date);
		    System.out.println("controller "+s.getElectionName());
		  if(s.getElectionName()==" ")
		    {
		    	response.sendRedirect("ViewRegisterFail.jsp");
		    	System.out.println("No election Today");
		    	
		    }
		    /*else if(s==null) {
		    	
		    }*/
		    else
		    {
				ArrayList<CandidateDetails> cBeans=svc.viewCandidatesAgainstElection(s);
				c.add(s.getElectionName());
				for(int i=0;i<cBeans.size();i++)
				{
					c.add(cBeans.get(i).getCandidateName());
				}
				
				if(c.size() > 0)
				{
					//System.out.println(s.toString());
					request.setAttribute("data", c);
					RequestDispatcher rd=request.getRequestDispatcher("VoteCasteSuccess.jsp");
					rd.forward(request, response);
				
				}
					else
					response.sendRedirect("VoteCastFail.jsp");
			   }
			}
			else {
				response.sendRedirect("VoteNotAuthenticated.jsp");
			}
		    }
		
		
		if(request.getParameter("evsButton").equalsIgnoreCase("cast vote")){
			Service svc = new Service();		
			//get username from session
			String uName = (String) session.getAttribute("uName");
			
			
			String cname = request.getParameter("Candidate ID");			
			String ename = request.getParameter("ElectionID");
			//System.out.println(ename);//for testing
			//System.out.println(cname);//for testing
			
			//DAO dao=new DAO();
			int cid=svc.getCandidateByName(cname);
			int eid=svc.getElectionByName(ename);
			//System.out.println(eid);
			VoteCasting vBean = new VoteCasting();
			//vBean.setVoter_id(vid);
			vBean.setCandidate_id(cid);
			vBean.setElection_id(eid);
			
			
			int voteCastSuccess = svc.castVote(vBean,uName);
			//System.out.println("controller" +voteCastSuccess );//for testing

			if(voteCastSuccess != 0)
				response.sendRedirect("VotingDoneSuccess.jsp");
			else
				response.sendRedirect("VotingDoneFail.jsp");
		}	
		if(trigerFrom.equalsIgnoreCase("View Candidate Against Particular Election")){
			Service svc = new Service();
			String d=java.time.LocalDate.now().toString();
		    String da[]=d.split("-");
		    String date=da[2]+"-"+da[1]+"-"+da[0];
			ArrayList<String> s=svc.viewUpcomingElectionNames(date);
			if(s.size()>0)
			{
				//System.out.println("arrayloidst made");//for testing
				
				request.setAttribute("electionNames", s);
				RequestDispatcher rd=request.getRequestDispatcher("ViewCandidateAgainstElection.jsp");
				rd.forward(request, response);
			}
			else
			{
				response.sendRedirect("ViewPartyDetailsFail.jsp");
			}
			
		}
		
		
		//US007
		if(trigerFrom.equalsIgnoreCase("See Election Result")) {
			Service serv = new Service();
			ArrayList<String> electionNames = serv.getElectionNames();
			
			if(electionNames.size() > 0) {
				
				//System.out.println(electionNames);//for testing
				request.setAttribute("electionNames", electionNames);
				RequestDispatcher rd = request.getRequestDispatcher("ViewResult.jsp");
				rd.forward(request, response);		
			}
			else {
				response.sendRedirect("ViewResultFailure.jsp");	
			}
		}				
		if(trigerFrom.equalsIgnoreCase("Click to View Result")) {
			
			Service serv = new Service();
			String electionName = request.getParameter("electionName");
			
			//System.out.println(electionName);//for testing
			ArrayList<String[]> allResults = serv.viewAllResult(electionName);
			
			//System.out.println(allResults);//for testing
			if(allResults.size()>0) {
				request.setAttribute("allName", allResults);
				RequestDispatcher rd = request.getRequestDispatcher("DisplayResult.jsp");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd = request.getRequestDispatcher("DisplayResultFail.jsp");
				rd.forward(request, response);
			}
			
		}
		
				
		//Logout
		if(trigerFrom.equalsIgnoreCase("Logout")){
			PrintWriter out = response.getWriter();	
			response.setContentType("text/html");		
			session.invalidate();	
			response.sendRedirect("index1.jsp");	
		}
		
		if(trigerFrom.equalsIgnoreCase("Forget Password")) {
			String userName = request.getParameter("username");
			int reqId = Integer.parseInt(request.getParameter("reqid"));

			Service s = new Service();
			String pass = s.getPassword(userName, reqId);
			
			if(pass.length() > 0) {
				response.sendRedirect("RecoverPassword.jsp?pass="+pass);
			}
			else {
				response.sendRedirect("RecoverPassword.jsp?pass="+pass);
			}
		}
	}
}







