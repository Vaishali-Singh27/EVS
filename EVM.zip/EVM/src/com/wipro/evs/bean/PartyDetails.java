package com.wipro.evs.bean;

import java.sql.Date;

public class PartyDetails {
	
	private String partyName;
	private String partyDate;
	private String partyPresident;
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getPartyDate() {
		return partyDate;
	}
	public void setPartyDate(String date) {
		this.partyDate = date;
	}
	public String getPartyPresident() {
		return partyPresident;
	}
	public void setPartyPresident(String partyPresident) {
		this.partyPresident = partyPresident;
	}

}
