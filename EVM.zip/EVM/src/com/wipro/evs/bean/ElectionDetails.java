package com.wipro.evs.bean;

import java.sql.Date;

public class ElectionDetails {
	
	private int electionId;
	private String electionName;
	private String electionDate;
	private String electionStatus;
	private String result;
	
	public int getElectionId() {
		return electionId;
	}
	public void setElectionId(int electionId) {
		this.electionId = electionId;
	}
	public String getElectionName() {
		return electionName;
	}
	public void setElectionName(String electionName) {
		this.electionName = electionName;
	}
	public String getElectionDate() {
		return electionDate;
	}
	public void setElectionDate(String date) {
		this.electionDate = date;
	}
	public String getElectionStatus() {
		return electionStatus;
	}
	public void setElectionStatus(String electionStatus) {
		this.electionStatus = electionStatus;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}

}
