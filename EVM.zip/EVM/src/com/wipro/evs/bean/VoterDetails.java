package com.wipro.evs.bean;

public class VoterDetails {
	String voterName;
	String voterDOB;
	String voterAddress;
	int voterId;
	int reqID;
	
	public int getVoterId() {
		return voterId;
	}
	public void setVoterId(int voterId) {
		this.voterId = voterId;
	}	
	public String getVoterName() {
		return voterName;
	}
	public void setVoterName(String voterName) {
		this.voterName = voterName;
	}
	public String getVoterDOB() {
		return voterDOB;
	}
	public void setVoterDOB(String voterDOB) {
		this.voterDOB = voterDOB;
	}
	public String getVoterAddress() {
		return voterAddress;
	}
	public void setVoterAddress(String voterAddress) {
		this.voterAddress = voterAddress;
	}	
	public int getReqID() {
		return reqID;
	}
	public void setReqID(int reqID) {
		this.reqID = reqID;
	}
}
