package com.wipro.evs.bean;

import java.sql.Date;

public class VoterRegistration {
	String voterName;
	String voterDOB;
	String voterAddress;
	int voterId;//it is reqId (i guess)
	String userName;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getVoterId() {
		return voterId;
	}
	public void setVoterId(int voterId) {
		this.voterId = voterId;
	}
	public String getVoterName() {
		return voterName;
	}
	public void setVoterName(String voterName) {
		this.voterName = voterName;
	}
	public String getVoterDOB() {
		return voterDOB;
	}
	public void setVoterDOB(String date) {
		this.voterDOB = date;
	}
	public String getVoterAddress() {
		return voterAddress;
	}
	public void setVoterAddress(String voterAddress) {
		this.voterAddress = voterAddress;
	}
}
