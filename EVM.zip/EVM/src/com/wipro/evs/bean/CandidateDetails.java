package com.wipro.evs.bean;

public class CandidateDetails {
	private int id;
	private String name;
	private String party;
	private int electionID;
	private String electionName;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getCandidateName() {
		return name;
	}
	
	public void setCandidateName(String name) {
		this.name = name;
	}
	
	public String getCandidateParty() {
		return party;
	}
	
	public void setCandidateParty(String party) {
		this.party = party;
	}
	
	public int getElectionID() {
		return electionID;
	}
	
	public void setElectionID(int electionID) {
		this.electionID = electionID;
	}
	
	public String getElectionName(){
		return electionName;
	}
	
	public void setElectionName(String elName){
		this.electionName = elName;
	}
}
