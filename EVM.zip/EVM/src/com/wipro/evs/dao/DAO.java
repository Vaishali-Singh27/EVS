package com.wipro.evs.dao;

//import com.sun.org.glassfish.external.statistics.annotations.Reset;
import com.wipro.evs.bean.*;
import com.wipro.evs.util.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.PreparedStatement;

public class DAO {
	//forget password
	public int setPassWordVoter(String pass1, String userName,int reqId ) {
        System.out.println("in dao");
        try {
            Connection connection = DBUtil.getDBConnection();
            System.out.println("in dao...database connected");
            String qry = "update evs_login_details SET password=? where username=? and username=(select user_name from evs_voter_details where user_name=? and VOTER_ID=?)";
            System.out.println("in dao...query saved");
            PreparedStatement preparedStatement3 = connection.prepareStatement(qry);
            System.out.println("in dao....preparedstatement object created");
            preparedStatement3.setString(1,pass1);
            System.out.println("in dao....preparedstatement object created parameter 1");
            preparedStatement3.setString(2,userName);
            preparedStatement3.setString(3,userName);
            preparedStatement3.setInt(4,reqId);
            System.out.println("in dao....preparedstatement object created para 2");
            int count = preparedStatement3.executeUpdate();
            System.out.println("in dao...query executed"+count);
            
            connection.close();
            preparedStatement3.close();
            return count;
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }
	
	
	//Login
	public LoginBean doLogin(LoginBean loginBean) {
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_login_details where username=? and password=?";
			
			//String query1 = "update evs_election_details set status='Done' where election_date<(SELECT TO_CHAR(CURRENT_DATE, 'DD-MON-YYYY') FROM dual)";
			String query1 = "update evs_election_details set status='Done' where election_date<to_Date('22-02-2019','dd-mm-yyyy')";
			PreparedStatement prepaStatement1 = connection.prepareStatement(query1);
			int a = prepaStatement1.executeUpdate();
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, loginBean.getUserName());
			preparedStatement.setString(2, loginBean.getPassword());
			ResultSet resultset = preparedStatement.executeQuery();
			
			if(resultset.next()){
				loginBean.setRole(resultset.getString("role"));
			}else{
			loginBean.setRole("");
			}
		}catch (Exception e) {
			System.out.println(e);
		}
		return loginBean;
	}
	
	//AD-001
	public int addElectionDetails(ElectionDetails electionDetails) {
		int count=0;
		try
		{			
			Connection connection = DBUtil.getDBConnection();			
			String query = "insert into evs_election_details(NAME,ELECTION_DATE,STATUS,RESULT) values(?,?,?,?)";
			
			System.out.println(electionDetails.getElectionDate());//for testing
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			//preparedStatement.setInt(1,electionDetails.getElectionId());
			preparedStatement.setString(1,electionDetails.getElectionName());
			
			String dateString = electionDetails.getElectionDate();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date=sdf.parse(dateString);
			java.sql.Date sdate=new java.sql.Date(date.getTime());
			
			preparedStatement.setDate(2, sdate);
			//preparedStatement.setString(3,"to_date('20/10/2019','dd/mm/yyyy')");//for testing
			preparedStatement.setString(3,"Pending");
			preparedStatement.setString(4,"Not declared");
			count = preparedStatement.executeUpdate();
			System.out.println(count);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return count;
	}
	
	
	//AD-002
	public ArrayList<ElectionDetails> viewUpcomingElections(String cuDate){
		
		ArrayList<ElectionDetails> electionDetailsList = new ArrayList<ElectionDetails>();
		try {
			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_election_details where election_date >= ?";
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date=sdf.parse(cuDate);
			java.sql.Date sdate=new java.sql.Date(date.getTime());
			
			preparedStatement.setDate(1,sdate);
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				ElectionDetails bean = new ElectionDetails();
				bean.setElectionId(resultSet.getInt("id"));
				bean.setElectionName(resultSet.getString("name"));
				bean.setElectionDate(resultSet.getString("election_date"));
				bean.setElectionStatus(resultSet.getString("status"));
				bean.setResult(resultSet.getString("result"));
				
				electionDetailsList.add(bean);
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(electionDetailsList.size()+" is the size");//for testing
		return electionDetailsList;
	}
	
	
	//AD-003
	public ArrayList<ElectionDetails> showElectionDetails()
	{
		ArrayList<ElectionDetails> list=new ArrayList<ElectionDetails>();
		try
		{
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_election_details ORDER BY ID";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			System.out.println("DAO");
			ResultSet rs=preparedStatement.executeQuery();
			
			while(rs.next())
			{
				System.out.println(list.size());
				ElectionDetails ed=new ElectionDetails();
				ed.setElectionId(rs.getInt(1));
				ed.setElectionName(rs.getString(2));
				ed.setElectionDate(rs.getString(3));
				ed.setElectionStatus(rs.getString(4));
				ed.setResult(rs.getString(5));
				list.add(ed);
				
			}
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return list;
	}
	
	//AD-004
	public int addPartyDetails(PartyDetails partyDetailsBean) {
		int count=0;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "insert into evs_party_details values (?,(to_date(?,'dd/mm/yyyy')),?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, partyDetailsBean.getPartyName());
			preparedStatement.setString(2, partyDetailsBean.getPartyDate());
			preparedStatement.setString(3, partyDetailsBean.getPartyPresident());
			count = preparedStatement.executeUpdate();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return count;
	}

	
	// AD-005
	public ArrayList<PartyDetails> viewAllPartyDetails() {
			ArrayList<PartyDetails> list=new ArrayList<PartyDetails>();
			try {			
				Connection connection = DBUtil.getDBConnection();
				String query = "select * from evs_party_details";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery();
				while(resultSet.next()) {
					PartyDetails bean = new PartyDetails();
					bean.setPartyName(resultSet.getString(1));
					bean.setPartyDate(resultSet.getString(2));
					bean.setPartyPresident(resultSet.getString(3));
					list.add(bean);
				}
				resultSet.close();
			} catch (Exception e) {
				System.out.println(e);
			}
			return list;
		}
	
	//AD-006:
	public int getElectionByName(String name)
	{
		int count=0;
		try
		{			
			Connection connection = DBUtil.getDBConnection();
			String query = "select id from evs_election_details where name=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,name);
			ResultSet resultset = preparedStatement.executeQuery();
			System.out.println("124354dfrdhfghjsxdfg57");
			
			if(resultset.next())
			{
				count=resultset.getInt(1);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return count;
		
	}
	public ArrayList<String> viewUpcomingElectionNames(String cuDate){
		
		ArrayList<String> names = new ArrayList<String>();
		try {
			
				Connection connection = DBUtil.getDBConnection();
				String query = "select name from evs_election_details where election_date >= ?";
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				//java.sql.Date sqlDate = java.sql.Date.valueOf( cuDate );
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	            java.util.Date d=sdf.parse(cuDate);
	            java.sql.Date ds=new java.sql.Date(d.getTime());
	            System.out.println(ds);
				preparedStatement.setDate(1,ds);
				System.out.println(cuDate+"DAO Currunt Date");
				
				ResultSet resultSet = preparedStatement.executeQuery();
				while(resultSet.next()) {
					names.add(resultSet.getString("name"));
				
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return names;
	}
	public int addCandidateDetails(CandidateDetails candidateDetails) {
		int count=0;
		int eleId=0;
		try
		{			
			Connection connection = DBUtil.getDBConnection();

			String query = "insert into evs_candidate_details(name,party_name,election_id,election_name) values(?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			//preparedStatement.setInt(1,candidateDetails.getId());
			preparedStatement.setString(1,candidateDetails.getCandidateName());
			preparedStatement.setString(2,candidateDetails.getCandidateParty());
			
			System.out.println(getElectionByName(candidateDetails.getElectionName()));
			System.out.println(candidateDetails.getElectionName());
			System.out.println(candidateDetails.getCandidateName());
			System.out.println(candidateDetails.getCandidateParty());
			
			preparedStatement.setInt(3,getElectionByName(candidateDetails.getElectionName()));
			preparedStatement.setString(4,candidateDetails.getElectionName());
			count = preparedStatement.executeUpdate();
			
			
//			String getElectionId="Select id from evs_election_details where name=?";
//			PreparedStatement electionId=connection.prepareStatement(getElectionId);
//			electionId.setString(1, candidateDetails.getElectionName());
//			ResultSet rs=electionId.executeQuery();
//			while(rs.next())
//				 eleId = rs.getInt("id");
//			
//			String resultQuery="insert into evs_election_result values(?,?,?)";
//			PreparedStatement electionResultEntry=connection.prepareStatement(resultQuery);
//			electionResultEntry.setInt(1, eleId);
//			electionResultEntry.setInt(2, candidateDetails.getId());
//			electionResultEntry.setInt(3,0);
//			int temp=electionResultEntry.executeUpdate();
		}
		catch (SQLException sql) {
			return -1;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return count;
	}
	
	
	//AD007
	public ArrayList<CandidateDetails> viewCandidatesAgainstElection(ElectionDetails electionDetails) {
		ArrayList<CandidateDetails> beans=new ArrayList<CandidateDetails>();
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_candidate_details where election_name=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,electionDetails.getElectionName());
				
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				CandidateDetails bean = new CandidateDetails();
				System.out.println(resultSet.getString("name"));
				bean.setCandidateName(resultSet.getString("name"));
				bean.setCandidateParty(resultSet.getString("party_name"));
				bean.setElectionID(resultSet.getInt("election_id"));
				bean.setElectionName(resultSet.getString("election_name"));
				beans.add(bean);
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beans;
	}
	
	
	//AD008: Admin wants to view pending voter's request
	public ArrayList<VoterRegistration> getPendingVotersList() {
		ArrayList<VoterRegistration> vtr =new ArrayList<VoterRegistration>();;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_registration_Request";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultset = preparedStatement.executeQuery();
			while(resultset.next()) {
				VoterRegistration vR=new VoterRegistration();
				vR.setVoterId(resultset.getInt(1));
				vR.setVoterName(resultset.getString(2));
				vR.setVoterDOB(resultset.getString(3));
				vR.setVoterAddress(resultset.getString(4));
				//System.out.println(resultset.getInt(1));
				vtr.add(vR);
			}
		}catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("DAo "+vtr.size());
		return vtr; 
	}
			
			
	//AD009
	public ArrayList<CandidateDetails> viewAllCandidateDetails() {
		ArrayList<CandidateDetails> beans=new ArrayList<CandidateDetails>();
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_candidate_details";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				CandidateDetails bean = new CandidateDetails();
				bean.setCandidateName(resultSet.getString("name"));
				bean.setCandidateParty(resultSet.getString("party_name"));
				bean.setElectionID(resultSet.getInt("election_id"));
				bean.setElectionName(resultSet.getString("election_name"));
				beans.add(bean);
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beans;
	}
	


	//AD-010
	public ArrayList<String[]> sendResults(String name) {
		
		//String [] resultList =new String[4];
		
		ArrayList<String []> resultList =new ArrayList<String[]>();
		
		try {
			int eId = 0;
			int temp=-1;
			Connection con = DBUtil.getDBConnection();
			
			//for counting and updating evs_election_result
			System.out.println("Before counting dao");
			String newQuery = "select id from evs_election_details where name = ?";
			PreparedStatement new_pstmt = con.prepareStatement(newQuery);
			new_pstmt.setString(1, name);
			
			ResultSet rs1 = new_pstmt.executeQuery();
			while(rs1.next()) {
				eId=rs1.getInt(1);
			}
			System.out.println("//"+eId);
					
					
					
					
			String calculateVot="Select candidate_Id,election_id,count(*) as totalvote from evs_vote_casting where election_id=? group by(candidate_Id,election_id)";
			PreparedStatement countVote=con.prepareStatement(calculateVot);
			countVote.setInt(1, eId);
			ResultSet result=countVote.executeQuery();
			while(result.next())
			{
				String insertResult="insert into evs_election_result values(?,?,?)";
				PreparedStatement countVoteWrite=con.prepareStatement(insertResult);
				System.out.println(result.getInt("candidate_id")+" "+result.getInt("totalvote")+" ");
				countVoteWrite.setInt(1,result.getInt(2));
				countVoteWrite.setInt(2, result.getInt(1));
				countVoteWrite.setInt(3,result.getInt(3));
				temp=countVoteWrite.executeUpdate();
				eId=result.getInt(2);
				
				
			}
			
			if(temp!=-1) {
				//updating evs_election_details table
				String update_election_result = "update evs_election_details set result='Declared' where id=?";
				PreparedStatement election_result = con.prepareStatement(update_election_result);
				election_result.setInt(1, eId);
				int update = election_result.executeUpdate();
				System.out.println("*"+update);
				
				System.out.println("AFter counting dao");
				//To display results 
				String resultQuery = "select evs_candidate_details.name , evs_candidate_details.party_name , evs_candidate_details.election_name , evs_election_result.number_of_votes from evs_election_result inner join evs_candidate_details on evs_candidate_details.id=evs_election_result.candidate_id and election_name=?";
				
				PreparedStatement resultStatement = con.prepareStatement(resultQuery);
				resultStatement.setString(1, name);
				ResultSet rs= resultStatement.executeQuery();
				
				while(rs.next()) {	
					String [] holder =new String[4];
					holder[0]=rs.getString("name");
					holder[1]=rs.getString("party_name");
					holder[2]=rs.getString("election_name");
					holder[3]=Integer.toString((int) rs.getInt("number_of_votes"));
					
					resultList.add(holder);	
				}
				
			}
			
			
			
			
			
		}catch(Exception e){
			System.out.println(e);	
		}
		System.out.println("DAO"+resultList);
		return resultList;
	}
	
	
	public ArrayList<String> onlyAdminViewResult(String name){
		Connection conn = DBUtil.getDBConnection();
		ArrayList<String> view = new ArrayList<String>();
		try {
			
			String query = "select name,count(*) as total_vote from evs_vote_casting inner join evs_candidate_details on evs_vote_casting.candidate_id=evs_candidate_details.id where election_name=? group by(name,evs_vote_casting.election_id)";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, name);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				String s = rs.getString(1)+" - "+rs.getInt(2);
				view.add(s);
				
			}
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println("SQL Exception");
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return view;
		
		
	}
	
	
	public ArrayList<String> getAdminElectionName() {
		ArrayList<String> list=new ArrayList<String>();
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_election_details where status='Done' and result='Not declared'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultset = preparedStatement.executeQuery();
			while(resultset.next())
			{
				String str=resultset.getString(2);
				System.out.println(str);
				//System.out.println(str);
				list.add(str);
			}
			}catch(Exception e) {
				System.out.println(e);
			}
			System.out.println("DAO "+list.size());
		return list;
	}
	
	
	//EO-001
	public ArrayList<VoterRegistration> viewRegistrationDetails() {
		
		ArrayList<VoterRegistration> registrationList =new ArrayList<VoterRegistration>();
		
		try {			
			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_registration_request";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				VoterRegistration bean = new VoterRegistration();
				System.out.println("result set "+resultSet.getString(2));//for testing

				bean.setVoterId(resultSet.getInt(1));
				bean.setVoterAddress(resultSet.getString(4));
				bean.setVoterName(resultSet.getString(2));
				bean.setVoterDOB(resultSet.getString(3));
				
				registrationList.add(bean);
			}
			
			System.out.println("DAO "+registrationList.size());
			
			resultSet.close();
			
		} catch (Exception e) {
			
			System.out.println(e);
		}
		return registrationList;
	}

			
	//EO-002
	public ArrayList<String> getRegId() {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<String>();
		try {
		Connection connection = DBUtil.getDBConnection();
		String query = "select ID from evs_registration_request";
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		ResultSet resultset = preparedStatement.executeQuery();
		while(resultset.next())
		{
			String str=String.valueOf(resultset.getInt(1));
			list.add(str);
		}
		}catch(Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public int voterApprove(String id) {
	
		int check=0;
		
		try {
			
			VoterRegistration registrationBean = new VoterRegistration();
			
			Connection connection = DBUtil.getDBConnection();
			String insertQuery = "insert into evs_voter_details(name,dob,address,reqid,user_name) select name,dob,address,id,user_name from evs_registration_request where id=?";
			
			//insert
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, id);	
			
			ResultSet rs = preparedStatement.executeQuery();
			preparedStatement.close();
			
			System.out.println("Insert done");
			//delete
			String deleteQuery ="delete from evs_registration_request where id=?";
			PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
			deleteStatement.setString(1, id);	
			
		    check  = deleteStatement.executeUpdate();
			deleteStatement.close();
				
			System.out.println("delete done");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
				
		return check;
		}
	public int voterReject(String id) {
		int check=0;
			
		VoterRegistration registrationBean = new VoterRegistration();
			
		try {
			Connection connection = DBUtil.getDBConnection();
				
			String deleteQuery ="delete from evs_registration_request where id=?";
			PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
			deleteStatement.setString(1, id);	
			
		    check  = deleteStatement.executeUpdate();
			deleteStatement.close();
				
			}catch (Exception e) {
				e.printStackTrace();				
			}
		return check;
	}
			
			
	//US-001: Voter wants to register to voting system
	public int voterLoginDetails(LoginBean lb) {
		int result = 0;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "insert into evs_login_details values(?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, lb.getUserName());
			preparedStatement.setString(2, lb.getPassword());
			preparedStatement.setString(3, lb.getRole());
			result = preparedStatement.executeUpdate();
			System.out.println(result);
		}
		catch (SQLException sql) {
			return -1;
		}
		
		catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}
	public int getVoterRegisterStatus(VoterRegistration vr) {
		int requestID = 0;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "insert into evs_registration_request(name,dob,address,user_name) values(?,(to_date(?,'dd/mm/yyyy')),?,?)";
			PreparedStatement preparedStatements = connection.prepareStatement(query);
			
//			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
//			java.util.Date date=sdf.parse(dateString);
//			java.sql.Date sdate=new java.sql.Date(date.getTime());
			
			preparedStatements.setString(1, vr.getVoterName());
			preparedStatements.setString(2, vr.getVoterDOB());
			preparedStatements.setString(3, vr.getVoterAddress());
			preparedStatements.setString(4, vr.getUserName());
			int resultset = preparedStatements.executeUpdate();
			if(resultset > 0) {
				String qry = "select ID from evs_registration_Request where NAME=? AND DOB=(to_date(?,'dd/mm/yyyy')) AND ADDRESS=?";				
				preparedStatements = connection.prepareStatement(qry);
				preparedStatements.setString(1, vr.getVoterName());
				preparedStatements.setString(2, vr.getVoterDOB());
				preparedStatements.setString(3, vr.getVoterAddress());
				ResultSet result = preparedStatements.executeQuery();
				//requestID = 1;//for testing
				while(result.next()) {
					System.out.println(result.getInt("ID"));
					requestID=result.getInt("ID");
				}
			}
		}catch (Exception e) {
			System.out.println(e);
		}
		return requestID;
	}

	
	//US-002
	public int getVoterId(int reqID) {
		int voterID = 0;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select VOTER_ID from EVS_VOTER_DETAILS where REQID=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, reqID);
			ResultSet resultset = preparedStatement.executeQuery();
			System.out.println("DAO");
			while(resultset.next()) {
				voterID = resultset.getInt("VOTER_ID");
			}
			
		}catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("DAO "+voterID);
		return voterID; 
	}
	
		
	//US-003 : Voter wants to view my VOTER-ID
			public VoterDetails getVoterIdDetails(VoterDetails vd) {
				// TODO Auto-generated method stub
				try {
					Connection conn = DBUtil.getDBConnection();
					String qr = "select * from EVS_VOTER_DETAILS where VOTER_ID=?";
					PreparedStatement ps = conn.prepareStatement(qr);
					ps.setInt(1, vd.getVoterId());
					ResultSet rs = ps.executeQuery();
					
					if(rs.next()) {
						vd.setVoterId(rs.getInt("VOTER_ID"));
						vd.setVoterName(rs.getString("NAME"));
						vd.setVoterDOB(rs.getString("DOB"));
						vd.setVoterAddress(rs.getString("ADDRESS"));
					}
					else {
						vd.setVoterId(0);
						vd.setVoterName("");
						vd.setVoterDOB("");
						vd.setVoterAddress("");
					}
				}catch (Exception e) {
					System.out.println(e);
				}
				return vd;
			}
			
	//US-005
	public ArrayList<String> getElectionName() {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<String>();
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_election_details where status='Pending' and result='Not declared'";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultset = preparedStatement.executeQuery();
			while(resultset.next())
			{
				String str=resultset.getString(2);
				System.out.println(str);
				//System.out.println(str);
				list.add(str);
			}
			}catch(Exception e) {
				System.out.println(e);
			}
			System.out.println("DAO "+list.size());
		return list;
	}
	public ArrayList<CandidateDetails> getCandidateDetailsByElection(String electionName) {
		// TODO Auto-generated method stub
		ArrayList<CandidateDetails> list=new ArrayList<CandidateDetails>();
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from evs_candidate_details where election_name=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			System.out.println(electionName+" dao");
			preparedStatement.setString(1,electionName);
			ResultSet resultset = preparedStatement.executeQuery();
			while(resultset.next())
			{
				CandidateDetails  cds=new CandidateDetails();
				cds.setId(resultset.getInt(1));
				cds.setCandidateName(resultset.getString(2));
				cds.setCandidateParty(resultset.getString(3));
				cds.setElectionID(resultset.getInt(4));
				cds.setElectionName(resultset.getString(5));
				//System.out.println(str);
				list.add(cds);
			}
			}catch(Exception e) {
				System.out.println(e);
			}		
		return list;
	}
	
		
	//DAO
	//US006
		public ElectionDetails getTodaysElection(String cuDate){
			ElectionDetails ed =new ElectionDetails();
			try {
				
				Connection connection = DBUtil.getDBConnection();
				String query = "select * from evs_election_details where election_date = ? and status='Pending' and result='Not declared'";
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				//java.sql.Date sqlDate = java.sql.Date.valueOf( cuDate );
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	            java.util.Date d=sdf.parse(cuDate);
	            java.sql.Date ds=new java.sql.Date(d.getTime());
	            System.out.println(ds);
				preparedStatement.setDate(1,ds);
				System.out.println(cuDate+" DAO Currunt Date");
				
				ResultSet resultSet = preparedStatement.executeQuery();
				if(resultSet.next()) {
					System.out.println(resultSet.getString("name"));
					ed.setElectionId(resultSet.getInt("id"));
					ed.setElectionName(resultSet.getString("name"));
					ed.setElectionDate(resultSet.getString("election_date"));
					ed.setElectionStatus(resultSet.getString("status"));
					ed.setResult(resultSet.getString("result"));
					}
				else
				{
					ed.setElectionName(" ");
				}
				resultSet.close();
			} catch (Exception e) {
				System.out.println(e);
			}
			return ed;
		}	
		public int getCandidateByName(String name)
		{
			int count=0;
			try
			{			
				Connection connection = DBUtil.getDBConnection();
				String query = "select id from evs_candidate_details where name=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1,name);
				ResultSet resultset = preparedStatement.executeQuery();
				System.out.println("124354dfrdhfghjsxdfg57");
				
				if(resultset.next())
				{
					count=resultset.getInt(1);
				}
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			return count;
			
		}
		public int castVote(VoteCasting voteCasting, String uName) {
			int count=0;
			try
			{			
				Connection connection = DBUtil.getDBConnection();
				DAO d = new DAO();
				int voterId = d.getVoterId(uName);
				
				if(voterId > 0) {
	
					try {	
						
						String query = "select count(*) from evs_vote_casting where voter_id=? and election_id=?";
						PreparedStatement preparedStatement = connection.prepareStatement(query);
						preparedStatement.setInt(1,voterId);
						preparedStatement.setInt(2,voteCasting.getElection_id());
						System.out.println(voteCasting.getVoter_id());
						
							
						ResultSet resultSet = preparedStatement.executeQuery();
						while(resultSet.next()) {
							System.out.println(resultSet.getInt(1));
							
							if(resultSet.getInt(1)>0) {
								return 0;
							}
						}
						
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					String query = "insert into evs_vote_casting values(?,?,?)";
					PreparedStatement preparedStatement = connection.prepareStatement(query);
					preparedStatement.setInt(1, voterId);
					preparedStatement.setInt(2,voteCasting.getCandidate_id());
					preparedStatement.setInt(3,voteCasting.getElection_id());
					System.out.println("Before ps dao");
					count = preparedStatement.executeUpdate();
					System.out.println("After ps dao");
				}
			}
			
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			return count;
		}

		
	//US007
	public ArrayList<String> viewElectionName(){
		
		ArrayList<String> election_name = new ArrayList<String>();
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select name from evs_election_details where status='Done' and result='Declared'";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				election_name.add(resultSet.getString(1));
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return election_name;
		
		
	}
		public ArrayList<String[]> showVoterResult(String electionName){
			
			ArrayList<String[]> allResult = new ArrayList<String[]>();
			try {
				Connection connection = DBUtil.getDBConnection();
				String query = "select evs_candidate_details.name , evs_candidate_details.party_name , evs_candidate_details.election_name , evs_election_result.number_of_votes from evs_election_result inner join evs_candidate_details on evs_candidate_details.id=evs_election_result.candidate_id and election_name=? order by(evs_election_result.number_of_votes) desc";
				PreparedStatement statement = connection.prepareStatement(query);
				statement.setString(1, electionName);
				ResultSet resultSet = statement.executeQuery();
				while(resultSet.next()) {
					String[] str = {resultSet.getString(1),resultSet.getString(2),resultSet.getString(3),Integer.toString(resultSet.getInt(4))};
					System.out.println(resultSet.getString(1)+resultSet.getString(2)+resultSet.getString(3)+Integer.toString(resultSet.getInt(4)));
					allResult.add(str);
				}
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			return allResult;
			
		}
		
		
		//US-003
		public int getVoterId(String uName) {
			int voterId = 0;
			try
			{			
				Connection connection = DBUtil.getDBConnection();
				
				String qry = "select voter_id from evs_voter_details where user_name=?";
				PreparedStatement preparedStatement1 = connection.prepareStatement(qry);
				preparedStatement1.setString(1,uName);
				ResultSet rs = preparedStatement1.executeQuery();
				while(rs.next())
					voterId = rs.getInt(1);
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
			
			return voterId;
		}
		
		
		//DAO
		//Forget Password
				public String getPassWord(String userName, int reqId) {
					// TODO Auto-generated method stub
					String pass = new String("");
					try {
						Connection connection = DBUtil.getDBConnection();
						String qry = "select password from evs_login_details where username=(select user_name from evs_registration_request where user_name=? and ID=?) or username=(select user_name from evs_voter_details where user_name=? and VOTER_ID=?)";
						PreparedStatement preparedStatement2 = connection.prepareStatement(qry);
						preparedStatement2.setString(1,userName);
						preparedStatement2.setInt(2,reqId);
						preparedStatement2.setString(3,userName);
						preparedStatement2.setInt(4,reqId);
						ResultSet rs1 = preparedStatement2.executeQuery();
						while(rs1.next())
							pass = rs1.getString(1);
					}
					catch (Exception e) {
						// TODO: handle exception
						System.out.println(e);
					}
					return pass;
				}

}
