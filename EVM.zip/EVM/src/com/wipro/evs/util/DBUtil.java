package com.wipro.evs.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection getDBConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.200.20.110:1521:orcl", "team6", "team6");
		
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	

}

