package com.wipro.evs.service;

import java.util.ArrayList;
import java.util.Calendar;

import com.wipro.evs.bean.*;
import com.wipro.evs.dao.*;

public class Service {
	
	//set passsword
    
    public int setPassWordVoter(String userName1, int reqId1,String pass1) {
        // TODO Auto-generated method stub
       
        System.out.println("in service");
        DAO da1 = new DAO();
        int a=da1.setPassWordVoter(pass1, userName1, reqId1);
        return a;
       
    }
	
	//login
	public LoginBean doLogin(LoginBean lbn){
		DAO dao = new DAO();
		LoginBean retBean = dao.doLogin(lbn);		// returned bean from DAO
		
		if(retBean.getRole().length() > 0)
			return retBean;
		
		return null;
	}
	
	
	//AD-001
	public int addElectionDetails(ElectionDetails detailsBean){
		DAO detailsDAO = new DAO();
		int electionDetailsAdded = detailsDAO.addElectionDetails(detailsBean);
		return electionDetailsAdded;
	}
	
	
	//AD-002
	public ArrayList<ElectionDetails> viewUpcomingElections(String currDate){
		DAO upcormingDAO = new DAO();
		ArrayList<ElectionDetails> upcomingElectionList = upcormingDAO.viewUpcomingElections(currDate);
		return upcomingElectionList;
		
	}
	
	
	// AD-003
	public ArrayList<ElectionDetails> viewElectionDetails(){
		//System.out.println("SERVICE");
		DAO electionDetailsDAO = new DAO();
		ArrayList<ElectionDetails> electionDetailsList = electionDetailsDAO.showElectionDetails();
		return electionDetailsList;
	}
	
	
	//AD-004
	public int addPartyDetails(PartyDetails bean)
	{
		DAO dao=new DAO();
		int count=	dao.addPartyDetails(bean);
		return count;
	}
	
		
	// AD-005 : View party details:
	public ArrayList<PartyDetails> viewAllPartyDetails()
	{
		ArrayList<PartyDetails> beans=new ArrayList<PartyDetails>();
		DAO dao=new DAO();
		beans=dao.viewAllPartyDetails();
		return beans;
	}

	
	//AD-006
	public int assignCandidateToElection(CandidateDetails cb){
		DAO assignElection = new DAO();
		int assignedSuccessfully = assignElection.addCandidateDetails(cb);
		return assignedSuccessfully;
	}
	public ArrayList<String> viewUpcomingElectionNames(String cuDate) {
		DAO electionDao = new DAO();
		ArrayList<String> elctionNames = electionDao.viewUpcomingElectionNames(cuDate);
		return elctionNames;
	}


	// AD-007:
	public ArrayList<CandidateDetails> viewCandidatesAgainstElection(ElectionDetails e){
		DAO detailsDAO = new DAO();
		ArrayList<CandidateDetails> detailsList = detailsDAO.viewCandidatesAgainstElection(e);
		//System.out.println("service "+detailsList.size());
		return detailsList;
	}	
		
				
	//AD008: Admin wants to view pending voter's request
	public ArrayList<VoterRegistration> getPendingVoters() {
		// TODO Auto-generated method stub
		DAO dao = new DAO();
		ArrayList<VoterRegistration> vtr = dao.getPendingVotersList();
		//System.out.println("SErvice "+vtr.size());
		return vtr;
	}
	
	
	//AD-009:
	public ArrayList<CandidateDetails> viewAllCandidates(){
		DAO electionDetailsDAO = new DAO();
		ArrayList<CandidateDetails> electionDetailsList = electionDetailsDAO.viewAllCandidateDetails();
		return electionDetailsList;
	}
	
	
	//AD-10
	public ArrayList<String> viewResults_approve(String name) {
		DAO dao = new DAO();
		ArrayList<String> list=dao.onlyAdminViewResult(name);
		return list;
	}
	public ArrayList<String[]> receiveResults(String name) {
		DAO dao = new DAO();
		ArrayList<String[]> list=dao.sendResults(name);
		return list;
	}
	public ArrayList<String> getAdminElectionName() {			
		DAO dao = new DAO();
		ArrayList<String> list=dao.getAdminElectionName();	
		return list;
	}
		
	//EO-001 
	public ArrayList<VoterRegistration> viewAllRegistraions(){
		DAO registrationDAO = new DAO();
		ArrayList<VoterRegistration> registrationList = registrationDAO.viewRegistrationDetails();
		//System.out.println("Service "+registrationList.size());//for testing
		return registrationList;
	}
		

	//EO-002 
	public ArrayList<String> getRegIdList() {
		// TODO Auto-generated method stub
		DAO dao = new DAO();
		ArrayList<String> list=dao.getRegId();
		//System.out.println("service "+list.size());//for testing
		return list;
	}
	public int approveVoter(String id) {
			
		DAO approveDao = new DAO();
		int check = approveDao.voterApprove(id);
		//System.out.println("service av"+check);//for testing
		return check;
	}
	public int rejectVoter(String id) {
		DAO approveDao = new DAO();
		int check = approveDao.voterReject(id);
		//System.out.println("service rv"+check);
		return check;		
	}
	
		
	//US-001: Voter wants to register to voting system
	public String addVoterLoginDetails(LoginBean lb) {
		DAO logDao = new DAO();
		int result = logDao.voterLoginDetails(lb);
		if(result > 0)
			return "success";
		else if(result==-1) {
			return "Exist";
		}
			return null;
	}	
	public int registerVoter(VoterRegistration vr) {
		DAO voterDao = new DAO();
		int requestID = voterDao.getVoterRegisterStatus(vr);
		return requestID;
	}
	
	
	//US-002
	public int getVoterID(int reqID) {
		DAO vtrDao = new DAO();
		int voterID = vtrDao.getVoterId(reqID);
		//System.out.println("Service "+voterID);
		return voterID;
	}
	
	
	//US-003 : Voter wants to view my VOTER-ID
	public VoterDetails voterIdDetails(VoterDetails vd) {
		// TODO Auto-generated method stub
		DAO vdDao = new DAO();
		VoterDetails vdt = vdDao.getVoterIdDetails(vd);
		return vdt;
	}
		
		

	//US-005
	public ArrayList<String> getElectionName() {
		// TODO Auto-generated method stub
		DAO dao=new DAO();
		ArrayList<String> electionName=dao.getElectionName();
		//System.out.println("Service "+electionName.size());
		return electionName;
	}
	public ArrayList<CandidateDetails> getCandidateDetailsByElection(String electionName) {
		// TODO Auto-generated method stub
		DAO dao=new DAO();
		ArrayList<CandidateDetails> list=dao.getCandidateDetailsByElection(electionName);
		return list;
	}

	public int getCandidateByName(String cn){
		DAO d = new DAO();
		int x = d.getCandidateByName(cn);
		return x;
	}
	
	public int getElectionByName(String en){
		DAO d = new DAO();
		int x = d.getElectionByName(en);
		return x;
	}
	
	
	//US-006
	//US-003
	public int getVoterIdService(String uName1) {
		// TODO Auto-generated method stub
		DAO d1 = new DAO();
		int voterID = d1.getVoterId(uName1);
		return voterID;
	}
	public ElectionDetails getTodaysElection(String cdate)
	{
		DAO dao=new DAO();
		ElectionDetails e=dao.getTodaysElection(cdate);
		return e;
	}
	
	public int castVote(VoteCasting vBean, String uName)
	{
		DAO d=new DAO();
		int x=d.castVote(vBean, uName);
		
		return x;
	}
	

	//US007
	public ArrayList<String[]> viewAllResult(String electionName){	
		DAO dao = new DAO();	
		ArrayList<String[]> allResult = dao.showVoterResult(electionName);	
		return allResult;	
	}
	public ArrayList<String> getElectionNames() {
		DAO electionDao = new DAO();
		ArrayList<String> elctionNames = electionDao.viewElectionName();
		return elctionNames;
	}
	
	//Forget Password
		public String getPassword(String userName, int reqId) {
			// TODO Auto-generated method stub
			DAO da = new DAO();
			String pass = da.getPassWord(userName, reqId);
			return pass;
		}
}
