/**
 * 
 */
function formValidation(){
//	var candidateId = document.forms["AssignCandidateAgainstParticularElection"]["Candidate ID"].value;
	var candidateName = document.forms["AssignCandidateAgainstParticularElection"]["Candidate name"].value;
	var candidateParty = document.forms["AssignCandidateAgainstParticularElection"]["Candidate party"].value;
	var electionName= document.forms["AssignCandidateAgainstParticularElection"]["Election name"].value;
	var patternAlph=/^[A-Za-z]+$/;
	
	
//
//	if(isNaN(candidateId)){
//		alert("Candidate Id: Type Numeric and Field: Not Empty");
//		return false;
//	}
	if(candidateName.length==0||!patternAlph.test(candidateName)){
		alert("Candidate Name : Type Alphabet or Field: Not Empty")
		return false;
	}
	if(candidateParty=="Select"){
		alert("Please select party name")
		return false;
	}
	
	if(electionName=="Select"){
		alert("Please select election type");
		return false;
	}
	
	return true;	
	
}