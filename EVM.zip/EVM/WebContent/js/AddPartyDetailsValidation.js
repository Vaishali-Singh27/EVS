
function addPartyDetailsValidation() {
	
	var party_name = document.forms["Add Party Details"]["party_name"].value;
	var letters = /^[A-Za-z ]*$/;
	if(!letters.test(party_name)){
		alert("Please Enter Characters Only");
		return false;
	}
	
	var established_date = document.forms["Add Party Details"]["established_date"].value;
	var datePattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
	

	if(!(datePattern.test(established_date))){
		alert("Date must be in the format DD-MM-YYYY");
		return false;
	}
	
	
	var parts = established_date.split('-');
	var established_date1 = new Date(parts[2], parts[1]-1, parts[0]);
	alert(established_date1.getYear());

	
	var today = new Date();
	
	var age = today.getFullYear() - established_date1.getFullYear();
	var m = today.getMonth() - established_date1.getMonth();

	if(m < 0 || (m === 0 && today.getDate() < established_date1.getDate())){
		age--;
	}
	
	if(age <1){
		alert("Eshtablishment Shoud Be Atleast Of 1 year");
		return false;
	}
	
	/*var parts = dob.split('-');
	var established_date1 = new Date(parts[2], parts[1]-1, parts[0]);
	alert(established_date1.getYear());
	
	var now = new Date();
	if(established_date1.getFullYear()>now.getFullYear()){
		alert("Date must be in the Past");
		return false;
	}
	/*else{
		
		if(established_date1.getMonth()>)
	}
	
	
	var form_date = new Date(established_date);
	var now = new Date();
	 if (form_date>now) {
		    alert("Date must be in the Past");
		    return false;
	}
	*/
	var president = document.forms["Add Party Details"]["president"].value;
	if(!letters.test(president)){
		alert("Please Enter Characters Only");
		return false;
	}
	return true;
	
}