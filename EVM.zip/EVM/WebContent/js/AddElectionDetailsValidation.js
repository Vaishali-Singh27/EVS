/**
 * 
 */

function validate(){
	//var elID = document.addeldetails.electionid.value;
	var elName = document.addeldetails.electionname.value;
	var elDate = document.addeldetails.electiondate.value;

	
	var datePattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
	var namePattern = /[^0-9]*$/g;
	


	if(elName.length==0 ||/\d/.test(elName)){
		alert("Election name must contain letters only");
		return false;
	}
	if(elDate.length==0 || !datePattern.test(elDate)){
		alert("Date must be in the format DD-MM-YYYY");
		return false;
	}
	
	var parts = elDate.split('-');
	var elDate1 = new Date(parts[2], parts[1], parts[0]);
	var q = new Date();
	var m = q.getMonth();
	var d = q.getDay();
	var y = q.getFullYear();

	var date1 = new Date(y,m,d);
	
	alert("Success");
	return true;
}
