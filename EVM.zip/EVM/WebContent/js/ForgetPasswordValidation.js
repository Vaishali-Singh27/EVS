function validatePassword(){
	var userName = document.forms["forgetPassword"]["username"].value;
	var nameRegex = /^[a-zA-Z\-]+$/;
	if(!nameRegex.test(userName)){
		alert("Your username is not valid. Only characters A-Z, a-z and '-' are  acceptable.");
		return false;
	}
	var reqId = document.forms["forgetPassword"]["reqid"].value;
	if(isNaN(reqId)){
		alert("Request-ID must be number");
		return false;
	}
	return true;
}