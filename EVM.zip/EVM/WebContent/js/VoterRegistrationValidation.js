function validateRegistration(){
	
	var userName = document.forms["voterRegistration"]["username"].value;
	var nameRegex = /^[a-zA-Z\-]+$/;
	if(!nameRegex.test(userName)){
		alert("Your username is not valid. Only characters A-Z, a-z and '-' are  acceptable.");
		return false;
	}
	
	var name = document.forms["voterRegistration"]["name"].value;
	var letters = /^[A-Za-z]+$/;
	if(!letters.test(name)){
		alert("Please Enter Characters Only for Name field");
		return false;
	}
	
	var password = document.forms["voterRegistration"]["password"].value;
	var confirm_password=document.forms["voterRegistration"]["confirmpassword"].value;
	if(!password.match(confirm_password)){
		alert("Password Doesn't match");
		return false;
	}
	
	var address = document.forms["voterRegistration"]["address"].value;	
	if(!letters.test(address)){
		alert("Please Enter Characters Only for Address field");
		return false;
	}
	
	var dob = document.forms["voterRegistration"]["dob"].value;
	var datePattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
	if(!(datePattern.test(dob))){
		alert("Date must be in the format DD-MM-YYYY");
		return false;
	}
	
	var parts = dob.split('-');
	var dob1 = new Date(parts[2], parts[1]-1, parts[0]);
	alert(dob1.getYear());

	
	var today = new Date();
	
	var age = today.getFullYear() - dob1.getFullYear();
	var m = today.getMonth() - dob1.getMonth();

	if(m < 0 || (m === 0 && today.getDate() < dob1.getDate())){
		age--;
	}
	
	if(age < 18){
		alert("You must be 18 years to vote");
		return false;
	}
	
	return true;
}